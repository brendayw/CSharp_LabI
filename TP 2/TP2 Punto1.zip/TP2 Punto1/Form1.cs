﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP2_Punto1
{
    public partial class fPrincipal : Form
    {
        public fPrincipal()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void bValorAbs_Click(object sender, EventArgs e)
        {
            double numero = double.Parse(tNumero.Text);
            double valorabsoluto = numero >= 0 ? numero : -numero;
            MessageBox.Show("el valor absoluto es: " + valorabsoluto);

        }

        private void bRedondear_Click(object sender, EventArgs e)
        {
            double numero = Convert.ToDouble(tNumero.Text);
            //numero = 3,54678
            //decimales = 0,54678
            double decimales = numero % 1;
            numero = numero - decimales;
            int numeroRedondeado;
            
            if (decimales >= 0.5)
            {               
                numeroRedondeado = Convert.ToInt32(numero) + 1;
                    
            }
            else
            {                
                    numeroRedondeado = Convert.ToInt32(numero);                            
            }

            //int numeroEntero = (int)numero;
            //int numeroRedondeado = numero - numeroEntero >= 0.5 ? numeroEntero + 1 : numeroEntero;
            MessageBox.Show("El numero " + (numero + decimales) + " redondeado es : " + numeroRedondeado);
        }
    }
}
