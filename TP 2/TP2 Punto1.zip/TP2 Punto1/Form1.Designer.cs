﻿namespace TP2_Punto1
{
    partial class fPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bCerrar = new System.Windows.Forms.Button();
            this.bValorAbs = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tNumero = new System.Windows.Forms.TextBox();
            this.bRedondear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bCerrar
            // 
            this.bCerrar.Location = new System.Drawing.Point(349, 320);
            this.bCerrar.Name = "bCerrar";
            this.bCerrar.Size = new System.Drawing.Size(75, 23);
            this.bCerrar.TabIndex = 0;
            this.bCerrar.Text = "Cerrar";
            this.bCerrar.UseVisualStyleBackColor = true;
            this.bCerrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // bValorAbs
            // 
            this.bValorAbs.Location = new System.Drawing.Point(36, 218);
            this.bValorAbs.Name = "bValorAbs";
            this.bValorAbs.Size = new System.Drawing.Size(138, 23);
            this.bValorAbs.TabIndex = 1;
            this.bValorAbs.Text = "Calcular el Valor absoluto";
            this.bValorAbs.UseVisualStyleBackColor = true;
            this.bValorAbs.Click += new System.EventHandler(this.bValorAbs_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 2;
            this.label1.Tag = "";
            this.label1.Text = "Ingrese un numero: ";
            // 
            // tNumero
            // 
            this.tNumero.Location = new System.Drawing.Point(132, 84);
            this.tNumero.Name = "tNumero";
            this.tNumero.Size = new System.Drawing.Size(100, 20);
            this.tNumero.TabIndex = 3;
            // 
            // bRedondear
            // 
            this.bRedondear.Location = new System.Drawing.Point(259, 218);
            this.bRedondear.Name = "bRedondear";
            this.bRedondear.Size = new System.Drawing.Size(75, 23);
            this.bRedondear.TabIndex = 4;
            this.bRedondear.Text = "Redondear";
            this.bRedondear.UseVisualStyleBackColor = true;
            this.bRedondear.Click += new System.EventHandler(this.bRedondear_Click);
            // 
            // fPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 355);
            this.Controls.Add(this.bRedondear);
            this.Controls.Add(this.tNumero);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bValorAbs);
            this.Controls.Add(this.bCerrar);
            this.Name = "fPrincipal";
            this.Text = "Punto 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bCerrar;
        private System.Windows.Forms.Button bValorAbs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tNumero;
        private System.Windows.Forms.Button bRedondear;
    }
}

