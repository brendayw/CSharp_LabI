﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP2Punto3
{
    public partial class fColores : Form
    {
        int rojo = 0;
        int amarillo = 0;
        int azul = 0;
        public fColores()
        {
            InitializeComponent();
        }

        private void bAmarillo_Click(object sender, EventArgs e)
        {
            if (bCerrar.Visible == false) bCerrar.Visible = true;
            if (BackColor == Color.Red)
            {
                BackColor = Color.Orange;
            }
            else if (BackColor == Color.Blue)
            {
                BackColor = Color.Green;
            }
            else if (BackColor == Color.Violet)
            {
                BackColor = Color.Black;
            }
            else
                BackColor = Color.Yellow;
            amarillo++;
        }

        private void bRojo_Click(object sender, EventArgs e)
        {
            if (BackColor == Color.Blue)
            {
                BackColor = Color.Violet;
            }
            else if (BackColor == Color.Yellow)
            {
                BackColor = Color.Orange;
            }
            else if (BackColor == Color.Green)
            {
                BackColor = Color.Black;
            }
            else
                BackColor = Color.Red;
            if (bCerrar.Visible == false) bCerrar.Visible = true;
            rojo++;
        }

        private void bAzul_Click(object sender, EventArgs e)
        {
            if (BackColor == Color.Red)
            {
                BackColor = Color.Violet;
            }
            else if (BackColor == Color.Yellow)
            {
                BackColor = Color.Green;
            }
            else if (BackColor == Color.Orange)
            {
                BackColor = Color.Black;
            }
            else
                BackColor = Color.Blue;
            if (bCerrar.Visible == false) bCerrar.Visible = true;
            azul++;
        }

        private void bCerrar_Click(object sender, EventArgs e)
        {
            string primero = "";
            string segundo = "";
            string tercero = "";

            if (amarillo >= rojo && amarillo >= azul)
            {
                primero = "1°. - Color “Amarillo”: " + amarillo + (amarillo == 1 ? " vez" : " veces");

                if (azul <= rojo)
                {
                    tercero = "3°. - Color “Azul”: " + azul + (azul == 1 ? " vez" : " veces");
                    segundo = "2°. - Color “Rojo”: " + rojo + (rojo == 1 ? " vez" : " veces");
                }
                else
                {
                    tercero = "3°. - Color “Rojo”: " + rojo + (rojo == 1 ? " vez" : " veces");
                    segundo = "2°. - Color “Azul”: " + azul + (azul == 1 ? " vez" : " veces");
                }
            }
            else if (rojo >= azul)
            {
                primero = "1°. - Color “Rojo”: " + rojo + (rojo == 1 ? " vez" : " veces");

                if (amarillo <= azul)
                {
                    tercero = "3°. - Color “Amarillo”: " + amarillo + (amarillo == 1 ? " vez" : " veces");
                    segundo = "2°. - Color “Azul”: " + azul + (azul == 1 ? " vez" : " veces");
                }
                else
                {
                    segundo = "2°. - Color “Amarillo”: " + amarillo + (amarillo == 1 ? " vez" : " veces");
                    tercero = "3°. - Color “Azul”: " + azul + (azul == 1 ? " vez" : " veces");
                }
            }
            else
            {
                primero = "1°. - Color “Azul”: " + azul + (azul == 1 ? " vez" : " veces");

                if (rojo <= amarillo)
                {
                    tercero = "3°. - Color “Rojo”: " + rojo + (rojo == 1 ? " vez" : " veces");
                    segundo = "2°. - Color “Amarillo”: " + amarillo + (amarillo == 1 ? " vez" : " veces");
                }
                else
                {
                    segundo = "2°. - Color “Rojo”: " + rojo + (rojo == 1 ? " vez" : " veces");
                    tercero = "3°. - Color “Amarillo”: " + amarillo + (amarillo == 1 ? " vez" : " veces");
                }
            }

            MessageBox.Show(primero + "\n" + segundo + "\n" + tercero);
            Close();
        }
    }
}
