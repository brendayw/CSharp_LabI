﻿namespace TP2Punto3
{
    partial class fColores
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bAmarillo = new System.Windows.Forms.Button();
            this.bRojo = new System.Windows.Forms.Button();
            this.bAzul = new System.Windows.Forms.Button();
            this.bCerrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bAmarillo
            // 
            this.bAmarillo.Location = new System.Drawing.Point(24, 39);
            this.bAmarillo.Name = "bAmarillo";
            this.bAmarillo.Size = new System.Drawing.Size(75, 23);
            this.bAmarillo.TabIndex = 0;
            this.bAmarillo.Text = "&Amarillo";
            this.bAmarillo.UseVisualStyleBackColor = true;
            this.bAmarillo.Click += new System.EventHandler(this.bAmarillo_Click);
            // 
            // bRojo
            // 
            this.bRojo.Location = new System.Drawing.Point(153, 39);
            this.bRojo.Name = "bRojo";
            this.bRojo.Size = new System.Drawing.Size(75, 23);
            this.bRojo.TabIndex = 1;
            this.bRojo.Text = "&Rojo";
            this.bRojo.UseVisualStyleBackColor = true;
            this.bRojo.Click += new System.EventHandler(this.bRojo_Click);
            // 
            // bAzul
            // 
            this.bAzul.Location = new System.Drawing.Point(282, 39);
            this.bAzul.Name = "bAzul";
            this.bAzul.Size = new System.Drawing.Size(75, 23);
            this.bAzul.TabIndex = 2;
            this.bAzul.Text = "A&zul";
            this.bAzul.UseVisualStyleBackColor = true;
            this.bAzul.Click += new System.EventHandler(this.bAzul_Click);
            // 
            // bCerrar
            // 
            this.bCerrar.Location = new System.Drawing.Point(282, 131);
            this.bCerrar.Name = "bCerrar";
            this.bCerrar.Size = new System.Drawing.Size(75, 23);
            this.bCerrar.TabIndex = 3;
            this.bCerrar.Text = "&Cerrar";
            this.bCerrar.UseVisualStyleBackColor = true;
            this.bCerrar.Visible = false;
            this.bCerrar.Click += new System.EventHandler(this.bCerrar_Click);
            // 
            // fColores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(392, 187);
            this.Controls.Add(this.bCerrar);
            this.Controls.Add(this.bAzul);
            this.Controls.Add(this.bRojo);
            this.Controls.Add(this.bAmarillo);
            this.Name = "fColores";
            this.Text = "Mezcla de Colores";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bAmarillo;
        private System.Windows.Forms.Button bRojo;
        private System.Windows.Forms.Button bAzul;
        private System.Windows.Forms.Button bCerrar;
    }
}

